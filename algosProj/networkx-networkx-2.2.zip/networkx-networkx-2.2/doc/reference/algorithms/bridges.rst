Bridges
=======

.. automodule:: networkx.algorithms.bridges
.. autosummary::
   :toctree: generated/

   bridges
   has_bridges
   local_bridges
