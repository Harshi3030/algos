*********************************
Version 1.7 notes and API changes
*********************************

This page reflects API changes from networkx-1.6 to networkx-1.7.

Please send comments and questions to the networkx-discuss mailing list:
http://groups.google.com/group/networkx-discuss .


Other
-----
* Untested bipartite_random_regular_graph() removed.

